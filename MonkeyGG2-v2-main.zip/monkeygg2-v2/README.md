# MonkeyGG2-v2

Cool gaming site going under a huge remake.